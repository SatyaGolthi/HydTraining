package com.cg.employee.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.employee.entities.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

	/*
	 * List<Employee> findByempId(int empId);
	 * 
	 * @Query(value="SELECT * FROM Employee e WHERE e.name = 'name'", nativeQuery =
	 * true) List<Employee> findByname();
	 */

}
