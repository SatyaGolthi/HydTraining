package com.cg.airlines_reservation_system;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.airlines_reservation_system.entity.BookingInformation;
import com.cg.airlines_reservation_system.entity.FlightInformation;
import com.cg.airlines_reservation_system.repository.BookingRepository;
import com.cg.airlines_reservation_system.repository.FlightRepository;
import com.cg.airlines_reservation_system.service.BookingServiceImpl;
import com.cg.airlines_reservation_system.service.FlightServiceImpl;
import com.cg.airlines_reservation_system.service.IBookingService;
import com.cg.airlines_reservation_system.service.IFlightService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AirlinesReservationSystemApplicationTests {

	@Mock
	FlightRepository flightRepository;
	@Mock
	BookingRepository bookingRepository;

	@InjectMocks
	FlightServiceImpl flightService;
	@InjectMocks
	BookingServiceImpl bookingService;
	
	
	@Test
	public void createFlight() throws Exception {
		FlightInformation expected = new FlightInformation();
		expected.setAirline("INDIGO");
		expected.setFlightId(100);
		expected.setDepCity("Hyderabad");
		expected.setArrCity("Bangalore");
		expected.setArrDate("22/04/2019");
		expected.setDepDate("22/04/2019");
		expected.setDepTime("11:30");
		expected.setArrTime("12:30");
		expected.setFirstSeats(100);
		expected.setFirstSeatsFare(2500);
		expected.setBusinessSeats(100);
		expected.setBusinessSeatsFare(25000);
		
	
		when(flightRepository.save(Mockito.any(FlightInformation.class))).thenReturn(expected);
		FlightInformation actual = flightService.createFlight(expected);
		System.out.println(expected.toString());
		System.out.println(actual.toString());
		assertEquals(expected, actual);
		
	}
	@Test
	public void addBooking() throws Exception {
		BookingInformation expected = new BookingInformation();
		expected.setBookingId(50);
		expected.setClassType("firstClass");
		expected.setCreditCardInfo("122335645");
		expected.setCustEmail("sai321@gmail.com");
		expected.setDestCity("Bangalore");
		expected.setNoOfPassengers(4);
		expected.setSeatNumber(11);
		expected.setTotalFare(2500);
		
		
	
		when(bookingRepository.save(Mockito.any(BookingInformation.class))).thenReturn(expected);
		Optional<BookingInformation> actual = bookingService.bookFlight(100, expected);
		System.out.println(expected.toString());
		System.out.println(actual.toString());
		assertEquals(expected, actual);
		
	}
	

}
