package com.cg.airlines_reservation_system.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.airlines_reservation_system.entity.BookingInformation;

@Repository
public interface BookingRepository extends JpaRepository<BookingInformation, Integer> {

	/*
	 * @Query("select b from BookingInformation b where b.flightId=:flightId")
	 * Optional<BookingInformation> getAllBookingsById(int flightId);
	 */

	@	Transactional
	@Modifying
	@Query("SELECT e FROM BookingInformation e WHERE e.flightId=:flightId")
	public List<BookingInformation> findByflightId(@Param(value="flightId")int flightId);

	@Transactional
	@Modifying
	@Query("SELECT  count(b.noOfPassengers) FROM BookingInformation b WHERE b.flightId=:flightId")
	public int findNoOfPassengersByflightId(int flightId);

}
