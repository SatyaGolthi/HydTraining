package com.cg.airlines_reservation_system.exception;

public class AirlinesException extends Exception {

	 private static final long serialVersionUID = 1L;
		
		private int code;
		private String message;
		public int getCode() {
			return code;
		}
		public void setCode(int code) {
			this.code = code;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public AirlinesException(int code, String message) {
			super();
			this.code = code;
			this.message = message;
		}
		public AirlinesException(String string) {
			super();
		}
			}
