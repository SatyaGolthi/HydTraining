package com.cg.airlines_reservation_system.service;

import java.util.List;
import java.util.Optional;

import com.cg.airlines_reservation_system.entity.BookingInformation;
import com.cg.airlines_reservation_system.entity.FlightInformation;
import com.cg.airlines_reservation_system.exception.AirlinesException;

public interface IFlightService {

	public	List<FlightInformation> getAllFlights();

	public FlightInformation createFlight(FlightInformation flight);

	public String deleteFlight(int flightNo);


	public List<FlightInformation> getParticularFlights(String depDate,String arrCity);

	public FlightInformation getFlightById(int flightId);

	public FlightInformation updateFlight(int flightId, String depDate, String arrDate, String depTime, String arrTime);

	public int noOfPassengers(int flightId) throws AirlinesException;

	
	
	

	

	

}
