package com.cg.airlines_reservation_system.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@Entity
@JsonIgnoreProperties({ "hibernateLazyInitializer","handler" })
@Table(name="BookingInformation")
public class BookingInformation implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="booking_seq")
	@SequenceGenerator(name="booking_seq",sequenceName="booking_seq",allocationSize=1,initialValue=50)
	private int bookingId;
	private int flightId;
	@JsonIgnore
	@ManyToOne(fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	@JoinColumn(name="flightId",insertable=false,updatable=false)
	private FlightInformation flight;
	
	@Email
	@Column(name="custEmail")
	private String custEmail;
	@NotNull(message="please enter the no of passengers")
	@Column(name="noOfPassengers")
	private int noOfPassengers;
	
	public BookingInformation() {
		// TODO Auto-generated constructor stub
	}

	@Column(name="classType")
	private String classType;
	@Column(name="seatNumber")
	private int seatNumber;
	
	@Column(name="totalFare")
	private float totalFare;
	
	
	@Column(name="creditCardInfo")
	private String creditCardInfo;
	
	@Column(name="destCity")
	private String destCity;

	
	
	
}

