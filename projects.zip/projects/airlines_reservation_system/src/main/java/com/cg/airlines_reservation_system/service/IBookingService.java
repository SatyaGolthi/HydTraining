package com.cg.airlines_reservation_system.service;

import java.util.List;
import java.util.Optional;

import com.cg.airlines_reservation_system.entity.BookingInformation;
import com.cg.airlines_reservation_system.exception.AirlinesException;

public interface IBookingService {

	
	public Optional<BookingInformation> getbooking(int bookingId);

	

	
	



	public List<BookingInformation> getAllBookings();

	public List<BookingInformation> getBookingsById(int flightId) throws AirlinesException;




	public String deleteFlight(int bookingId);




	public BookingInformation updateBooking(int bookingId, String custEmail, int noOfPassengers,
			String classType);




	







	Optional<BookingInformation> bookFlight(int flightId, BookingInformation book);




	
}
